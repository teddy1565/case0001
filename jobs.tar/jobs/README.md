# 工作項目

# 大綱
預期設計兩個頁面,其一為編輯頁面, 該編輯頁面需要呈現 
1. 標題{XXX公司條款編輯} 
2. select:條款主題編輯(若選擇新增則轉換為 input)
3. 編輯網頁內容用的 textarea
4. submit button

![edit page](./edit_page.jpg)


則還有展示頁面, 本頁需要透過 GET:id 將指定的 "條款" 展示出來

![content page](./content_page.jpg)


mysql schema: 
  CREATE TABLE db.clause ( id INT NOT NULL AUTO_INCREMENT , topic VARCHAR(50) NOT NULL , author VARCHAR(50) NOT NULL , update_when DATE NOT NULL , content MEDIUMTEXT NOT NULL , PRIMARY KEY (id)) ENGINE = InnoDB; 